import pytest
from pydantic import ValidationError

from epc.models import BearerConfig


class TestBearerConfig:
    #max=9
    def test_bearer_id_higher(self):
        with pytest.raises(ValidationError):
            BearerConfig(bearer_id=10)

    #only tcp and udp
    def test_invalid_protocol(self):
        with pytest.raises(ValidationError):
            BearerConfig(bearer_id=1, protocol="http")