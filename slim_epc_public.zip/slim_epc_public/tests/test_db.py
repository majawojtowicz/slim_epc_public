import pytest

from epc.models import ThroughputStats

class TestAttachDetach:
    def test_attach_adds(self, repo):
        repo.attach_ue(1)
        assert 1 in list(repo.list_ues())